package azc.uam.model;

public interface ISeparator {
    String[] separate(Text text);
}
