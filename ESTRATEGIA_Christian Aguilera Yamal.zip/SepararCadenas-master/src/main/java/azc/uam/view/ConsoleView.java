/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package azc.uam.view;

/**
 *
 * @author Alumno02
 */
public class ConsoleView {
    public void showResult(String[] elements){
        for(String s: elements){
            System.out.println(" - " + s);
        }
        System.out.println("");
    }
}
