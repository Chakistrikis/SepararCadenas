/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package azc.uam.controller;

import azc.uam.model.ISeparator;
import azc.uam.model.Text;

/**
 *
 * @author Alumno02
 */
public class TextController {
    private Text text;
    
    public TextController(){
        text = new Text();
    }

    public Text getText() {
        return text;
    }

    public void setText(String input) {
        text.setText(input);
    }
    
    public void useSeparator(ISeparator separator){
        text.setSeparator(separator);
    }
    
    public String[] obtainSplit(){
        return text.split();
    }
}
